<?php
$file = "bookings.txt";

echo "<div class='admin-container'>";
echo "<h2>Admin Panel - View All Bookings</h2>";

if (file_exists($file) && is_readable($file)) {
    $bookings = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    echo "<table>";
    echo "<tr>
            <th>Name</th>
            <th>Course</th>
            <th>Role</th>
            <th>Phone Number</th>
            <th>Item</th>
            <th>Start Time</th>
            <th>End Time</th>
            <th>Purpose</th>
            <th>Actions</th>
          </tr>";

    $index = 0;
    foreach ($bookings as $booking) {
        $parts = explode('|', $booking);
        if (count($parts) !== 8) continue;
        list($name, $course, $role, $phone_number, $item, $start, $end, $purpose) = $parts;
        if (!is_numeric($start) || !is_numeric($end) || $start >= $end) continue;
        $startFormatted = date("Y-m-d H:i", (int)$start);
        $endFormatted = date("Y-m-d H:i", (int)$end);

        echo "<tr>
                <td>$name</td>
                <td>$course</td>
                <td>$role</td>
                <td>$phone_number</td>
                <td>$item</td>
                <td>$startFormatted</td>
                <td>$endFormatted</td>
                <td>$purpose</td>
                <td>
                    <button class='remove-btn' data-index='$index'>Remove</button>
                </td>
              </tr>";
        $index++;
    }

    echo "</table>";
} else {
    echo "<p>No bookings found.</p>";
}

echo "</div>";
?>