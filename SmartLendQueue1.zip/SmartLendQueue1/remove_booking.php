<?php
header('Content-Type: application/json');

ob_start();

$response = ["status" => "error", "message" => ""];

$index = filter_input(INPUT_GET, 'index', FILTER_VALIDATE_INT);
if ($index === null || $index === false || $index < 0) {
    $response["message"] = "Invalid index";
    echo json_encode($response);
    ob_end_flush();
    exit;
}

$file = "bookings.txt";
if (!file_exists($file)) {
    if (file_put_contents($file, "") === false) {
        error_log("remove_booking.php: Failed to create bookings.txt");
        $response["message"] = "Failed to create bookings file";
        echo json_encode($response);
        ob_end_flush();
        exit;
    }
}

if (is_readable($file) && is_writable($file)) {
    $bookings = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($index < count($bookings)) {
        unset($bookings[$index]);
        $bookings = array_values($bookings);
        $content = "";
        if (!empty($bookings)) {
            $content = implode(PHP_EOL, $bookings) . PHP_EOL;
        }
        if (file_put_contents($file, $content) !== false) {
            $response["status"] = "success";
            $response["message"] = "Booking removed successfully";
        } else {
            error_log("remove_booking.php: Failed to write to bookings.txt");
            $response["message"] = "Failed to write to bookings file";
        }
    } else {
        $response["message"] = "Index out of range";
    }
} else {
    error_log("remove_booking.php: Cannot access bookings.txt");
    $response["message"] = "Cannot access bookings file. Check permissions.";
}

echo json_encode($response);
ob_end_flush();
?>