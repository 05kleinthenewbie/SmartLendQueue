<?php
header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

// Enable error reporting (log only)
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'C:/xampp/htdocs/borrow_system/SmartLendQueue/php_errors.log');

$unavailable_items = [];

function sanitize_string($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

$start_time_str = sanitize_string($_GET['start_time'] ?? '');
$end_time_str = sanitize_string($_GET['end_time'] ?? '');

if (!$start_time_str || !$end_time_str) {
    error_log("check_availability.php: Missing start_time or end_time");
    echo json_encode($unavailable_items);
    exit;
}

$start_time = strtotime($start_time_str);
$end_time = strtotime($end_time_str);

if ($start_time === false || $end_time === false || $start_time >= $end_time) {
    error_log("check_availability.php: Invalid date/time - start: $start_time_str, end: $end_time_str");
    echo json_encode($unavailable_items);
    exit;
}

$file = "bookings.txt";
if (file_exists($file) && is_readable($file)) {
    $bookings = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($bookings as $booking) {
        $parts = explode('|', $booking);
        if (count($parts) !== 8) {
            error_log("check_availability.php: Invalid booking format: $booking");
            continue;
        }
        $item = trim($parts[4]);
        $booking_start = (int)trim($parts[5]);
        $booking_end = (int)trim($parts[6]);
        if ($booking_start <= 0 || $booking_end <= 0 || $booking_start >= $booking_end) {
            error_log("check_availability.php: Invalid booking timestamps: start=$booking_start, end=$booking_end");
            continue;
        }
        if (!($end_time <= $booking_start || $start_time >= $booking_end)) {
            if (!in_array($item, $unavailable_items)) {
                $unavailable_items[] = $item;
            }
        }
    }
} else {
    error_log("check_availability.php: bookings.txt does not exist or is not readable");
}

echo json_encode($unavailable_items);
?>