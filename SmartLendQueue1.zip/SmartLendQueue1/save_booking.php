<?php
header('Content-Type: text/plain');

// Enable error reporting (log only, no display)
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'C:/xampp/htdocs/borrow_system/SmartLendQueue/php_errors.log');

// Sanitize input
function sanitize_string($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

$name = sanitize_string($_POST['name'] ?? '');
$course = sanitize_string($_POST['course'] ?? '');
$phone_number = sanitize_string($_POST['phone_number'] ?? '');
$role = sanitize_string($_POST['role'] ?? '');
$item = sanitize_string($_POST['item'] ?? '');
$start_time = sanitize_string($_POST['start_time'] ?? '');
$end_time = sanitize_string($_POST['end_time'] ?? '');
$purpose = sanitize_string($_POST['purpose'] ?? '');

if (!$name || !$course || !$phone_number || !$role || !$item || !$start_time || !$end_time || !$purpose) {
    error_log("save_booking.php: Missing required fields");
    echo "Missing required fields";
    exit;
}

$start_timestamp = strtotime($start_time);
$end_timestamp = strtotime($end_time);

if ($start_timestamp === false || $end_timestamp === false || $start_timestamp >= $end_timestamp) {
    error_log("save_booking.php: Invalid date/time - start: $start_time, end: $end_time");
    echo "Invalid date/time";
    exit;
}

$booking = "$name|$course|$role|$phone_number|$item|$start_timestamp|$end_timestamp|$purpose";

$file = "bookings.txt";

// Create file if it doesn't exist
if (!file_exists($file)) {
    if (file_put_contents($file, "") === false) {
        error_log("save_booking.php: Failed to create bookings.txt");
        echo "Failed to create bookings file";
        exit;
    }
}

// Check writability
if (!is_writable($file)) {
    error_log("save_booking.php: bookings.txt is not writable");
    echo "Cannot write to bookings file. Check permissions.";
    exit;
}

// Write booking
if (file_put_contents($file, $booking . PHP_EOL, FILE_APPEND | LOCK_EX) !== false) {
    echo "success";
} else {
    error_log("save_booking.php: Failed to write to bookings.txt");
    echo "Failed to save booking";
}
?>